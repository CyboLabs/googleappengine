// Copyright 2012 Google Inc. All rights reserved.

package com.google.appengine.api.xmpp;

/**
 * Constructs an instance of the XMPP service.
 *
 */
public interface IXMPPServiceFactory {

   XMPPService getXMPPService();

}
